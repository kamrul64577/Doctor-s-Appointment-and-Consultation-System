const express = require('express');
const path = require('path');
const mysql = require('mysql');
const dotenv = require('dotenv');

const cookieParser = require('cookie-parser');
const { requireAuth } = require('./middleware/middlewareAuth');

dotenv.config( { path: './.env' } )

const app = express();

const db = mysql.createConnection({
  host: process.env.DATABASE_HOST,
  user: process.env.DATABASE_USER,
  password: process.env.DATABASE_PASSWORD,
  database: process.env.DATABASE

});

const publicDirectory = path.join(__dirname, './public');
app.use(express.static(publicDirectory));

app.use(express.urlencoded({extended: false}));
app.use(express.json());
app.use(cookieParser());

app.set('viewengine', 'hbs');

db.connect((error) =>{
  if(error){
    console.log('error connecting: ' + error);
    
  }else{
    console.log("Database connected..");
  }
});

app.get('/login', (req,res) => res.render('login.hbs'))
app.get('/register', (req,res) => res.render('register.hbs'))
app.get('/', requireAuth,(req,res) => res.render('index.hbs'))
app.get('/hospital', requireAuth,(req,res) => res.render('hospital.hbs'))
app.get('/categories', requireAuth,(req,res) => res.render('categories.hbs'))


  app.get('/categories1',function(req,res){
    db.query('SELECT * FROM specialist', function(err, row) {
      if(err){
          console.log(err)
      }
      else{
        console.log(row)
        res.render('categories1.hbs', {msg:row})
          
      }
  })
  })




//app.use('/', ('./routes/pages.js'))
app.use('/auth', require('./routes/auth'))








const cors = require('cors');
const { categories } = require('./controllers/auth');
app.use(cors());
app.use(express.json());

// app.post("/ibnsinaSp", (req, res) => {
//   const name = req.body.name ;
//   const hname= req.body.hname ;
//   const email = req.body.email ;
//   db.query('INSERT INTO hospital_name (name,hname,email) VALUES (?,?,?)', [name,hname,email],
//    (err, result) =>{
//     if(err){
//       console.log(err);
//     }else{
//       res.send("value Inserted");
//     }
//   });

// });

app.get("/HospitalName", (req, res) => {
  db.query("SELECT * FROM hospital_name", (err, result) => {
    if (err) {
      console.log(err);
    } else {
      console.log('hi')
      res.send(result);
    }
  });
});









app.listen(3001,()=> console.log("listening port 3001"));