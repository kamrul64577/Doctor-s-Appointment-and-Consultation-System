const express = require('express');
const path = require('path');
const mysql = require('mysql');
const dotenv = require('dotenv');

const cookieParser = require('cookie-parser');
const { requireAuth } = require('./middleware/middlewareAuth');

dotenv.config( { path: './.env' } )

const app = express();

const db = mysql.createConnection({
  host: process.env.DATABASE_HOST,
  user: process.env.DATABASE_USER,
  password: process.env.DATABASE_PASSWORD,
  database: process.env.DATABASE

});

const publicDirectory = path.join(__dirname, './public');
app.use(express.static(publicDirectory));

app.use(express.urlencoded({extended: false}));
app.use(express.json());
app.use(cookieParser());

app.set('viewengine', 'hbs');

db.connect((error) =>{
  if(error){
    console.log('error connecting: ' + error);
    
  }else{
    console.log("Database connected..");
  }
});

app.get('/login', (req,res) => res.render('login.hbs'))
app.get('/register', (req,res) => res.render('register.hbs'))
app.get('/', requireAuth,(req,res) => res.render('index.hbs'))
//app.use('/', ('./routes/pages.js'))
app.use('/auth', require('./routes/auth'))

app.listen(3001,()=> console.log("listening port 3001"));